package com.github.midros.istheapp.di

import javax.inject.Scope

/**
 * Created by luis rafael on 19/02/18.
 */
@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class PerActivity