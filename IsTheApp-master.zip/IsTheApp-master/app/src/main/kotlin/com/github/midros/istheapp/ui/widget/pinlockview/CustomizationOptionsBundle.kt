package com.github.midros.istheapp.ui.widget.pinlockview

/**
 * Created by luis rafael on 01/05/19.
 */
data class CustomizationOptionsBundle (val textSize: Int, val buttonSize: Int, val deleteButtonSize: Int)

