package com.github.midros.istheapp.services.calls

import com.github.midros.istheapp.services.base.InterfaceService

/**
 * Created by luis rafael on 27/03/18.
 */
interface InterfaceServiceCalls  : InterfaceService{

    fun stopServiceCalls()

}