package com.github.midros.istheapp.data.model

/**
 * Created by luis rafael on 28/03/18.
 */
data class DataDelete(val key:String,val child:String,val file:String)