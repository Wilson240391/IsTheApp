package com.github.midros.istheapp.ui.activities.login

import com.github.midros.istheapp.ui.activities.base.InterfaceView

/**
 * Created by luis rafael on 9/03/18.
 */
interface InterfaceViewLogin : InterfaceView